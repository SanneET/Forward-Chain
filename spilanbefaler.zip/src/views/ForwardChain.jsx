import { useState } from 'react';
import gameImage from '../assets/game.jpg';
import '../App.css';

export default function GameRecommendation() {
  // Knowledge base - Holder brugerens svar på spørgsmålene
  const [facts, setFacts] = useState({
    multiplayer: null, // Om brugeren vil spille multiplayer eller ej
    battle_royal: null, // Om brugeren vil spille battle royal
    RPG: null, // Om brugeren vil spille RPG (rollespil)
  });

  // Reset function - Nulstiller alle svar og starter processen forfra
  const resetGame = () => {
    setFacts({ multiplayer: null, battle_royal: null, RPG: null });
  };

  // User Interface (UI) - Viser spørgsmål med Ja/Nej-knapper
  const askQuestion = (fact, question) => {
    return (
      <div key={fact} className="question">
        <p>{question}</p>
        <button className="btn yes" onClick={() => setFacts({ ...facts, [fact]: "Yes" })}>Yes</button>
        <button className="btn no" onClick={() => setFacts({ ...facts, [fact]: "No" })}>No</button>
      </div>
    );
  };

  // Inference engine - Beslutningsmotor, der styrer rækkefølgen af spørgsmålene og giver en anbefaling
  const forwardChain = () => {
    // Første spørgsmål: Multiplayer
    if (facts.multiplayer === null) {
      return askQuestion('multiplayer', 'Skal det være multiplayer?');
    }

    // Hvis multiplayer, spørg om battle royal
    if (facts.multiplayer === "Yes" && facts.battle_royal === null) {
      return askQuestion('battle_royal', 'Skal det være battle royal?');
    }

    // Hvis ikke battle royal, spørg om RPG
    if ((facts.multiplayer === "No" || facts.battle_royal === "No") && facts.RPG === null) {
      return askQuestion('RPG', 'Skal det være RPG?');
    }

    let result = '';

    // Anbefaling baseret på brugerens svar
    if (facts.multiplayer === "Yes" && facts.battle_royal === "Yes") {
      result = 'Du skal spille Apex Legends';
    } else if (facts.multiplayer === "Yes" && facts.RPG === "Yes") {
      result = 'Du skal spille Baldurs Gate 3';
    } else if (facts.multiplayer === "No" && facts.RPG === "Yes") {
      result = 'Du skal spille The Witcher 3';
    } else if (facts.RPG === "No") {
      result = 'Du skal ikke spille';
    } else {
      result = 'Ingen anbefaling baseret på dine valg.';
    }

    // Returnerer resultatet og en knap til at starte forfra
    return (
      <div className="result">
        <p>{result}</p>
        <button className="btn reset" onClick={resetGame}>Start forfra</button>
      </div>
    );
  };

  return (
    <div className="container">
      <h1>Spil Anbefaling</h1>
      {/* Viser billede i toppen */}
      <img src={gameImage} alt="Game Recommendation" className="game-image" />
      {/* Starter kæden af spørgsmål og anbefalinger */}
      {forwardChain()}
    </div>
  );
}